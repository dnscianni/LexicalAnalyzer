/**
 * 
 */
package edu.csupomona.cs.cs411.Project1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * @author David
 *
 */
public class Project1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

//		PrintWriter outfile;
//		try {
//			outfile = new PrintWriter("test.dat");
//
//			outfile.println("int fact (int x) { ");
//			outfile.println("// recursive factorial function ");
//			outfile.println("if (x>1) return x * fact(x-1); ");
//			outfile.println("else return 1;");
//			outfile.println(" } ");
//			outfile.println("void main () {");
//			outfile.println("/* Winter Quarter 2014");
//			outfile.println("CS 411 project #1 ");
//			outfile.println("A lexical analyzer  */");
//			outfile.println("\"this is a test\"");
//			outfile.println("0x73Ea8 {");
//			outfile.println("0 123 .2 0. 123.4");
//			outfile.println("12.e+12 3.24E1");
//			outfile.println("0");
//			outfile.println("x = x / 2");
//			outfile.close();
//		} catch (FileNotFoundException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
		
//		FileReader inputStream = null;
//		try {
//			inputStream = new FileReader("test.dat");
//			int c;
//			char d;
//            while ((c = inputStream.read()) != -1) {
//            	d = (char)c;
//                System.out.print(d);
//            }
//            inputStream.close();
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		try {
			LexicalAnalyzer la = new LexicalAnalyzer("test.toy", "output1.dat");
			la.lex();
			la.testPrint();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
